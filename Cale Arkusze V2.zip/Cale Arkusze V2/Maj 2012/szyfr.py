def z1():
    with open('tj.txt') as f:
        slowa = [line.strip() for line in f]
    with open('klucze1.txt') as f:
        klucze = [line.strip() for line in f]
    for i in range(len(slowa)):
        zaszyfrowane = ''
        slowo = slowa[i]
        klucz = klucze[i]
        uzupelniacz = []
        while len(uzupelniacz) < len(slowo):
            for i in range(len(klucz)):
                uzupelniacz.append(klucz[i])
        for j in range(len(slowo)):
            ascii = ord(slowo[j]) + ord(uzupelniacz[j])
            if ascii > 90:
                ascii -= 26
            zaszyfrowane += chr(ascii)
        print(zaszyfrowane)

def z2():
    with open('sz.txt') as f:
        slowa = [line.strip() for line in f]
    with open('klucze2.txt') as f:
        klucze = [line.strip() for line in f]
    for i in range(len(slowa)):
        zaszyfrowane = ''
        slowo = slowa[i]
        klucz = klucze[i]
        uzupelniacz = []
        while len(uzupelniacz) < len(slowo):
            for i in range(len(klucz)):
                uzupelniacz.append(klucz[i])
        for j in range(len(slowo)):
            ascii = ord(slowo[j]) + ord(uzupelniacz[j])
            if ascii < 65:
                ascii += 26
            zaszyfrowane += chr(ascii)
        print(zaszyfrowane)

z1()
z2()