with open('NAPIS.TXT') as f:
    napisy = [line.strip() for line in f]

def czyPierwsza(n):
    if n == 1:
        return False
    if n == 2:
        return True
    i = 3
    while i < n:
        if n % i == 0:
            return False
        i += 1
    return True

def z1():
    ile = 0
    for napis in napisy:
        suma = 0
        for litera in napis:
            suma += ord(litera)
        if czyPierwsza(suma):
            ile += 1
    print(ile)

def z2():
    for napis in napisy:
        poprawny = True
        for i in range(len(napis)-1):
            if ord(napis[i]) > ord(napis[i+1]):
                poprawny = False
        if poprawny:
            print(napis)

def z3():
    jedenRaz = []
    for napis in napisy:
        if napis not in jedenRaz:
            jedenRaz.append(napis)
        else:
            print(napis)

print("Zadanie 1:")
z1()
print("Zadanie 2:")
z2()
print("Zadanie 3:")
z3()