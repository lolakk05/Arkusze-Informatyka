import math

#Zadanie 3.1
print((2**3) % 11)
print((5**2) % 31)
print((2**6) % 59)
print((9**2) % 80)
#Zadanie 3.2

with open('liczby.txt') as f:
    liczby = [line.strip().split() for line in f]

# Zadanie 3.3
def z3():
    ile = 0
    for liczba in liczby:
        M = int(liczba[0])
        pierwsza = True
        if M < 2:
            pierwsza = False
        else:
            for i in range(2, int(math.sqrt(M))+1):
                if M % i == 0:
                    pierwsza = False
                    break
        if pierwsza:
            ile += 1
    print(ile)

#Zadanie 3.4
def NWD(a, b):
    if b == 0:
        return a
    return NWD(b, a%b)

def z4():
    ile = 0
    for liczba in liczby:
        M = int(liczba[0])
        a = int(liczba[1])
        if NWD(M, a) == 1:
            ile += 1
    print(ile)

#Zadanie 3.5
def z5():
    ile = 0
    for liczba in liczby:
        print(liczba)
        M = int(liczba[0])
        a = int(liczba[1])
        b = int(liczba[2])
        for x in range(0, M):
            if pow(a, x, M) == b:
                ile += 1
                break
    print(ile)

print('Zadanie 3:')
z3()
print("Zadanie 4:")
z4()
print("Zadanie 5:")
z5()