
A = [1,5,6,7,2]
dp = [1] * len(A)

for i in range(len(A)):
    for j in range(i):
        if A[i] > A[j]:
            dp[i] = max(dp[j]+1, dp[i])
print(max(dp))

print(5 + ((1 + 2) * 4) - 3)