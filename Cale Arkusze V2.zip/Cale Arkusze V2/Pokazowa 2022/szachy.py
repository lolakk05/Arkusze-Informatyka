with open('szachy_przyklad.txt') as f:
    plansze = []
    plansza = []
    for line in f:
        if line.strip() != "":
            plansza.append(line.strip())
        else:
            plansze.append(plansza[:])
            plansza.clear()
    plansze.append(plansza[:])


def z1():
    ile = 0
    ileMax = 0
    for plansza in plansze:
        ileKolumn = 0
        jednaWolna = False
        kolumny = [0] * 8
        for wiersz in plansza:
            poz = 0
            for kolumna in wiersz:
                if kolumna == ".":
                    kolumny[poz] += 1
                poz += 1
        for i in range(len(kolumny)):
            if kolumny[i] == 8:
                ileKolumn += 1
                jednaWolna = True
        if jednaWolna:
            ile += 1
            if ileKolumn > ileMax:
                ileMax = ileKolumn
    print(ile, ileMax)

def z2():
    ile = 0
    ileMin = 64
    for plansza in plansze:
        czarne = []
        biale = []
        for wiersz in plansza:
            for kolumna in wiersz:
                if ord(kolumna) >= 65 and ord(kolumna) <= 90:
                    biale.append(kolumna)
                if ord(kolumna) >= 97 and ord(kolumna) <= 122:
                    czarne.append(kolumna.upper())
        czarne = sorted(czarne)
        biale = sorted(biale)
        if czarne == biale:
            ile += 1
            if len(czarne) < ileMin:
                ileMin = len(czarne) * 2
    print(ile, ileMin)

z1()
z2()
z3()