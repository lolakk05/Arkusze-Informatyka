import math

def bubble():
    tekst = [1,5124,1241,242]
    for i in range(len(tekst)):
        for j in range(i, len(tekst)):
            if tekst[j] < tekst[i]:
                tekst[i], tekst[j] = tekst[j], tekst[i]
    return tekst

def nwd(a, b):
    if b == 0:
        return a
    else:
        return nwd(b, a%b)

def czy_pierwsza(n):
    if n < 2:
        return False
    for i in range(2, int(math.sqrt(n))+1):
        if n % i == 0:
            return False
    return True

def sito_pedala(n):
    sito = [True] * n
    sito[0] = False
    sito[1] = False
    for i in range(2, int(n**0.5)+1):
        if sito[i] == True:
            j = i * i
            while j <= n:
                sito[j] = False
                j += i
    return sito

def potegowanie(a, b):
    wynik = 1
    while b > 0:
        if b % 2 == 1:
            wynik *= a
        a *= a
        b //= 2
    return wynik

def lis():
    A = [1,2,3]
    dp = [1] * len(A)
    for i in range(len(A)):
        for j in range(i):
            if A[i] > A[j]:
                dp[j] = max(dp[j]+1, dp[i])
    return max(dp)

def cezar():
    tekst = 'abc'
    szyfr = ''
    przesuniecie = 1
    for znak in tekst:
        znak = chr((ord(znak) - ord('a') + przesuniecie) % 26 + ord('a'))
        szyfr += znak
    return szyfr

def lcs(X, Y):
    m, n = len(X), len(Y)
    dp = [[0] * (n + 1) for _ in range(m + 1)]

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if X[i - 1] == Y[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    return dp[m][n]

def quick(lista):
    if len(lista) <= 1:
        return lista
    pivot = lista[len((lista) // 2]
    lewo = [x for x in lista if x < pivot]
    srodek = [x for x in lista if x == pivot]
    prawo = [x for x in lista if x > pivot]
    return quick(lewo) + srodek + quick(prawo)

def binary(lista, x):
    lewy, prawy = 0, len(lista)-1
    while lewy <= prawy:
        srodek = (lewy + prawy) // 2
        if lista[srodek] == x:
            return srodek
        elif lista[srodek] < x:
            lewy = srodek + 1
        else:
            prawy = srodek - 1
    return -1
