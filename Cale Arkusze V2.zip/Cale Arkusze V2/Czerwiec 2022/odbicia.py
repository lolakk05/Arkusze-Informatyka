with open('liczby.txt') as f:
    liczby = [line.strip() for line in f]

def czyPierwsza(n):
    if n == 1:
        return False
    if n == 2:
        return True
    i = 3
    while i < n:
        if n % i == 0:
            return False
        i += 1
    return True

def z1():
    for liczba in liczby:
        if int(liczba[::-1]) % 17 == 0:
            print(liczba[::-1])

def z2():
    max = 0
    liczbaMax = 0
    for liczba in liczby:
        wartoscBezwgledna = abs(int(liczba) - int(liczba[::-1]))
        if wartoscBezwgledna > max:
            max = wartoscBezwgledna
            liczbaMax = liczba
    print(liczbaMax, max)

def z3():
    for liczba in liczby:
        if czyPierwsza(int(liczba)):
            if czyPierwsza(int(liczba[::-1])):
                print(liczba)

def z4():
    rozne = {}
    ileDwa = 0
    ileTrzy = 0
    for liczba in liczby:
        if liczba not in rozne:
            rozne[liczba] = 1
        else:
            rozne[liczba] += 1
    for liczba in rozne:
        if rozne[liczba] == 2:
            ileDwa += 1
        if rozne[liczba] == 3:
            ileTrzy += 1
    print(len(rozne), ileDwa, ileTrzy)
z1()
z2()
z3()
z4()