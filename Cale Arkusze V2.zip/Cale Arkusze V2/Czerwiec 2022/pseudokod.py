n = 123
suma = 0
while n > 0:
    cyfra = n % 10
    kwadrat = cyfra * cyfra
    suma = suma + kwadrat
    n = n // 10
print(suma)