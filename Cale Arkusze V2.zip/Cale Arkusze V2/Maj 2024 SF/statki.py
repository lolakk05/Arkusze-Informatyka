with open('plansza.txt') as f:
    plansza = [line.strip().split() for line in f]

for wiersz in plansza:
    print(wiersz)

def z1():
    ile = 0
    for y in range(len(plansza)):
        for x in range(len(plansza)):
            if plansza[y][x] == "0":
                kord = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
                nieStyka = True
                for k in kord:
                    if y + k[0] < 0 or y + k[0] > 99 or x + k[1] < 0 or x + k[1] > 99:
                        continue
                    else:
                        if plansza[y+k[0]][x+k[1]] == "1":
                            nieStyka = False
                if nieStyka:
                    ile += 1
    print(ile)

def z2():
    ile = 0
    for i in range(0, 99):
        kord = [[0, -1], [0, 1]]
        for k in kord:
            if i + k[1] < 0 or i + k[1] > 99:
                continue
            else:
                if plansza[i][i+k[1]] == "1":
                    ile += 1
    print(ile)

def z3():
    ile = 0
    for y in range(len(plansza)):
        for x in range(len(plansza)):
            if plansza[y][x] == "1":
                kord = [[-1, 0], [0, -1], [0, 1],[1, 0]]
                ileMasztow = 0
                for k in kord:
                    if y + k[0] < 0 or y + k[0] > 99 or x + k[1] < 0 or x + k[1] > 99:
                        continue
                    else:
                        if plansza[y+k[0]][x+k[1]] == "1":
                            ileMasztow += 1
                if ileMasztow == 1:
                    ile += 1
    print(ile//2)

def z4():
    ile = 0
    pozycjeJeden = []
    pozycjeDwu = []
    for i in range(0, 99):
        if plansza[i][i] == '1':
            kord = [[-1, 0], [0, -1], [0, 1],[1, 0]]
            ileMasztow = 1
            for k in kord:
                if i + k[1] < 0 or i + k[1] > 99:
                    continue
                else:
                    if plansza[i+k[0]][i + k[1]] == "1":
                        ileMasztow += 1
                    pozycja = f"{i}{i}"
            if ileMasztow == 1:
                if pozycja not in pozycjeJeden:
                    pozycjeJeden.append(pozycja)
            if ileMasztow == 2:
                if pozycja not in pozycjeDwu:
                    pozycjeDwu.append(pozycja)
    j = 9
    i = 0
    while j >= 0:
        if plansza[i][j] == '1':
            kord = [[-1, 0], [0, -1], [0, 1],[1, 0]]
            ileMasztow = 1
            for k in kord:
                if i + k[0] < 0 or i + k[0] > 9 or j + k[1] < 0 or j + k[1] > 9:
                    continue
                else:
                    if plansza[i+k[0]][j + k[1]] == "1":
                        ileMasztow += 1
                    pozycja = f"{i}{j}"
            if ileMasztow == 1:
                if pozycja not in pozycjeJeden:
                    pozycjeJeden.append(pozycja)
            if ileMasztow == 2:
                if pozycja not in pozycjeDwu:
                    pozycjeDwu.append(pozycja)
        j -= 1
        i += 1
    print(len(pozycjeJeden), len(pozycjeDwu))

# z1()
# z2()
# z3()
z4()