import math

with open('slowa.txt') as f:
    slowa = [line.strip() for line in f]

def z1():
    ile = 0
    for slowo in slowa:
        for i in range(1, len(slowo)-1):
            if slowo[i-1] == "k" and slowo[i+1] == "t":
                ile += 1
    print(ile)

def z2():
    ile = 0
    max = ''
    maxDl = 0
    for slowo in slowa:
        szyfr = ''
        for znak in slowo:
            szyfr += chr((ord(znak) - ord('a') + 13) % 26 + ord('a'))
        if szyfr == slowo[::-1]:
            ile += 1
            if len(szyfr) > maxDl:
                max = slowo
                maxDl = len(slowo)
    print(ile, max)

def z3():
    for slowo in slowa:
        ile = {}
        for znak in slowo:
            if znak not in ile:
                ile[znak] = 1
            else:
                ile[znak] += 1
        for znak in ile:
            if ile[znak] >= len(slowo) / 2:
                print(slowo)
                break

z1()
z2()
z3()
print(int('0025'))