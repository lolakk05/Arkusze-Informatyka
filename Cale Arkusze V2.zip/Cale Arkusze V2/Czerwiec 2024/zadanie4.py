#Zadanie 4.1
# 635454
# 564545
# 455454

with open('odbiorcy.txt') as f:
    komputery = [line.strip() for line in f]

def z1():
    ile = 0
    odbiorcy = {}
    for i in range(1, len(komputery)+1):
        odbiorcy[i] = 0
    for komputer in komputery:
        odbiorcy[int(komputer)] += 1
    for komp in odbiorcy:
        if odbiorcy[komp] == 0:
            ile += 1
    print(ile)

def z2():
    pakiety = komputery[:]
    print(pakiety)
    wrocil = False
    while wrocil == False:
        for nr in range(len(pakiety)):



z1()
z2()