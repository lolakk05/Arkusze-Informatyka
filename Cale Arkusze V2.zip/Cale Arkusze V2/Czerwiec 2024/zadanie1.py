#Zadanie 1.1
#10110
#01110
#11001
#11011
print(bin(179).lstrip('0b'))
#Zadanie 1.2
w = 5
k = 3
n = 19
pole = w * k
