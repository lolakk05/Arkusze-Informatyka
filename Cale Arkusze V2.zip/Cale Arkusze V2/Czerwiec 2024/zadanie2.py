#Zadanie 2.1
# 10 6
# 12 7
# Zadanie 2.2
# 256
# 511
def F(x):
    if x == 0:
        return 0
    else:
        return 2 + F(x // 2)


max = 0
min = 100000
for i in range(0, 10000):
    w = F(i)
    if w == 18 and i < min:
        min = i
    if w == 18 and i > max:
        max = i
print(min, max)