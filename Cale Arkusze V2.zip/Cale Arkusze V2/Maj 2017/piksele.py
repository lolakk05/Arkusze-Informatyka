with open('przyklad.txt') as f:
    piksele = [line.strip().split() for line in f]

def z1():
    max = 0
    min = 256
    for wiersz in piksele:
        for piksel in wiersz:
            if int(piksel) > max:
                max = int(piksel)
            if int(piksel) < min:
                min = int(piksel)
    print(max, min)

def z2():
    ile = 0
    for wiersz in piksele:
        if wiersz[::] != wiersz[::-1]:
            ile += 1
    print(ile)

def z3():
    ile = 0
    kord = ((1,0),(-1, 0),(0,1),(0,-1))
    for x in range(0, 319):
        for y in range(0, 199):
           kontrastujace = 0
           for k in kord:
               if x+k[0]>319 or x+k[0]<0 or y+k[1]>199 or y+k[1] < 0:
                   continue
               else:
                   if abs(int(piksele[y][x]) - int(piksele[y+k[1]][x+k[0]])) > 128:
                       kontrastujace += 1
           if kontrastujace != 0:
               ile += 1
    print(ile)

def z4():
    max = 0
    for x in range(0, 320):
        dl = 1
        for y in range(1, 200):
            if piksele[y-1][x] == piksele[y][x]:
                dl += 1
            else:
                if dl > max:
                    max = dl
                dl = 1
    print(max)

z1()
z2()
z3()
z4()