from collections import Counter

with open('instrukcje.txt') as f:
    instrukcje = [line.strip().split() for line in f]

def z1():
    dl = 0
    for instrukcja in instrukcje:
        if instrukcja[0] == "DOPISZ":
            dl += 1
        if instrukcja[0] == "USUN":
            dl -= 1
    print(dl)

def z2():
    dl = 1
    max = 0
    instrukcja = ""
    for i in range(len(instrukcje)-1):
        ostatni = instrukcje[i][0]
        if instrukcje[i][0] == instrukcje[i+1][0]:
            dl += 1
        else:
            if dl > max:
                max = dl
                instrukcja = instrukcje[i][0]
            dl = 1
    if dl > max:
        max = dl
        instrukcja = ostatni
    print(instrukcja, max)

def z3():
    litery = {}
    for instrukcja in instrukcje:
        if instrukcja[0] == "DOPISZ":
            if instrukcja[1] not in litery:
                litery[instrukcja[1]] = 1
            else:
                litery[instrukcja[1]] += 1
    print(Counter(litery).most_common(1))

def z4():
    haslo = ""
    for instrukcja in instrukcje:
        if instrukcja[0] == "DOPISZ":
            haslo += instrukcja[1]
        if instrukcja[0] == "USUN":
            haslo = haslo[:-1]
        if instrukcja[0] == "ZMIEN":
            haslo = haslo[:-1]
            haslo += instrukcja[1]
        if instrukcja[0] == "PRZESUN":
            pom = haslo
            haslo = ""
            pierwsze = True
            for znak in pom:
                if znak == instrukcja[1] and pierwsze:
                    if znak == "Z":
                        znak = "A"
                    else:
                        znak = chr(ord(znak)+1)
                    pierwsze = False
                haslo += znak
    print(haslo)

print("Zadanie 1")
z1()
print("Zadanie 2")
z2()
print("Zadanie 3")
z3()
print("Zadanie 4")
z4()