n = 2021
wynik = 0
p = 1
while n > 0:
    cyfra = n % 10
    dopelnienie = 9 - cyfra
    wynik = (p * dopelnienie) + wynik
    p = p * 10
    n = n // 10
print(wynik)
