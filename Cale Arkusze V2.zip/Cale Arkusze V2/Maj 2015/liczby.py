with open('liczby.txt') as f:
    liczby = [line.strip() for line in f]

def z1():
    ile = 0
    for liczba in liczby:
        ileZer = 0
        ileJed = 0
        for cyfra in liczba:
            if cyfra == "0":
                ileZer += 1
            else:
                ileJed += 1
        if ileZer > ileJed:
            ile += 1
    print(ile)

def z2():
    osiem = 0
    dwa = 0
    for liczba in liczby:
        if int(liczba, 2) % 2 == 0:
            dwa += 1
        if int(liczba, 2) % 8 == 0:
            osiem += 1
    print(dwa, osiem)

def z3():
    max = ""
    min = ""
    maxLiczba = 0
    minLiczba = 10000000000000000000000
    wierszMax = 0
    wierszMin = 0
    wiersz = 1
    for liczba in liczby:
        if int(liczba, 2) > maxLiczba:
            max = liczba
            maxLiczba = int(liczba, 2)
            wierszMax = wiersz
        if int(liczba, 2) < minLiczba:
            min = liczba
            minLiczba = int(liczba, 2)
            wierszMin = wiersz
        wiersz += 1
    print(max, wierszMax)
    print(min, wierszMin)

print("Zadanie 1")
z1()
print("Zadanie 2")
z2()
print("Zadanie 3")
z3()