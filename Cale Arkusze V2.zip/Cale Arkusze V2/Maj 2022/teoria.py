s = 'aabab'
n = len(s)

# indeksy w Pythonie zaczynają się od 0, więc musimy stworzyć odpowiednio większe tablice
A = [0] * (n + 1)       # A[0] do A[n]
B = [0] * (n + 2)       # B[1] do B[n+1] – indeks n+1 też ma być

# A[0] = 0 już jest ustawione domyślnie
for i in range(1, n + 1):
    if s[i - 1] == 'a':         # s[0] to pierwszy znak
        A[i] = A[i - 1] + 1
    else:
        A[i] = A[i - 1]

# B[n + 1] = 0 już ustawione domyślnie
for j in range(n, 0, -1):       # od n do 1 włącznie
    if s[j - 1] == 'b':
        B[j] = B[j + 1] + 1
    else:
        B[j] = B[j + 1]

k = 1
for i in range(0, n + 1):       # od 0 do n włącznie
    if A[i] + B[i + 1] > k:
        k = A[i] + B[i + 1]

print(k)