with open('liczby.txt') as f:
    liczby = [line.strip() for line in f]

def czyPierwsza(n):
    if n == 2:
        return True
    i = 3
    while i < n:
        if n % i == 0:
            return False
        i += 1
    return True

def z1():
    ile = 0
    pierwsza = ""
    for liczba in liczby:
        if liczba[0] == liczba[-1]:
            ile += 1
            if pierwsza == "":
                pierwsza = liczba
    print(ile, pierwsza)

def z2():
    max = 0
    maxLiczba = 0
    maxRozne = 0
    maxRozneLiczba = 0
    for liczba in liczby:
        liczba = int(liczba)
        pom = liczba
        ile = 0
        rozne = []
        dzielnik = 2
        while liczba > 1:
            if liczba % dzielnik == 0:
                if czyPierwsza(dzielnik):
                    ile +=1
                    if dzielnik not in rozne:
                        rozne.append(dzielnik)
                liczba //= dzielnik
            else:
                dzielnik += 1
        if ile > max:
            max = ile
            maxLiczba = pom
        if len(rozne) > maxRozne:
            maxRozne = len(rozne)
            maxRozneLiczba = pom
    print(maxLiczba, max, maxRozneLiczba, maxRozne)

def z3():
    ile = 0
    for i in range(len(liczby)):
        liczby[i] = int(liczby[i])
    for i in range(len(liczby)):
        for j in range(len(liczby)):
            if liczby[j] % liczby[i] == 0 and liczby[j] != liczby[i]:
                for k in range(len(liczby)):
                    if liczby[k] % liczby[j] == 0 and liczby[k] != liczby[j]:
                        ile += 1
    print(ile)

def z3b():
    ile = 0
    for i in range(len(liczby)):
        liczby[i] = int(liczby[i])
    for i in range(len(liczby)):
        for j in range(len(liczby)):
            if liczby[j] % liczby[i] == 0 and liczby[j] != liczby[i]:
                for k in range(len(liczby)):
                    if liczby[k] % liczby[j] == 0 and liczby[k] != liczby[j]:
                        for m in range(len(liczby)):
                            if liczby[m] % liczby[k] == 0 and liczby[m] != liczby[k]:
                                for n in range(len(liczby)):
                                    if liczby[n] % liczby[m] == 0 and liczby[n] != liczby[m]:
                                        ile += 1
    print(ile)
print("Zadanie 1")
z1()
print("Zadanie 2")
z2()
print("Zadanie 3")
z3()
z3b()