n = 297
b = 1
m = 0
while n > 0:
    cyfra = n % 10
    if cyfra % 2 == 1:
        m += (b*cyfra)
        b *= 10
    n //= 10
print(m)