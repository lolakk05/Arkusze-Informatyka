with open('liczby.txt') as f:
    liczby = [line.strip().split() for line in f]

wiersz1 = liczby[0]
wiersz2 = liczby[1]

for i in range(len(wiersz1)):
    wiersz1[i] = int(wiersz1[i])

for i in range(len(wiersz2)):
    wiersz2[i] = int(wiersz2[i])

def z1():
    print("Zadanie 1")
    ile = 0
    for w1 in wiersz1:
        for w2 in wiersz2:
            if w2 % w1 == 0:
                ile += 1
                break
    print(ile)

def z2():
    print("Zadanie 2")
    x = wiersz1[:]
    x.sort(reverse=True)
    print(x[100])

def z3():
    print("Zadanie 3")
    for w2 in wiersz2:
        liczba = w2
        for w1 in wiersz1:
            if liczba % w1 == 0:
                liczba //= w1
        if liczba == 1:
            print(w2)

def z4():
    print("Zadanie 4")
    max = 0
    pierwszyMax = 0
    dlMax = 0
    print(wiersz1)
    for i in range(len(wiersz1)):
        suma = 0
        dl = 0
        pierwszy = wiersz1[i]
        for j in range(i, i + 50):
            if j < len(wiersz1):
                suma += wiersz1[j]
                dl += 1
        srednia = suma / dl
        if srednia > max and dl >= 50:
            max = srednia
            pierwszyMax = pierwszy
            dlMax = dl
        indeks = i + 50
        while indeks < len(wiersz1):
            suma += wiersz1[indeks]
            dl += 1
            srednia = suma / dl
            if srednia > max and dl >= 50:
                max = srednia
                pierwszyMax = pierwszy
                dlMax = dl
            indeks += 1
    print(max, dlMax, pierwszyMax)
z1()
z2()
z3()
z4()