import math


def z1():
    ile = 0
    max = 0
    with open('skrot.txt') as f:
        liczby = [line.strip() for line in f]
    for liczba in liczby:
        poprawne = True
        for cyfra in liczba:
            if int(cyfra) % 2 == 1:
                poprawne = False
        if poprawne:
            ile += 1
            if int(liczba) > max:
                max = int(liczba)
    print(ile, max)

def z2():
    with open('skrot2.txt') as f:
        liczby = [int(line.strip()) for line in f]
    for liczba in liczby:
        skrot = 0
        b = 1
        pom = liczba
        while pom > 0:
            cyfra = pom % 10
            if cyfra % 2 == 1:
                skrot += (b * cyfra)
                b *= 10
            pom //= 10
        if math.gcd(liczba, skrot) == 7:
            print(liczba)


z1()
z2()