# Zadanie 2.1
# 121101 2
# 41312111011121314 8
# Zadanie 2.2
# 111111333333111111 12
def F(n):
    global ile
    b = 1
    c = 0
    while n > 0:
        a = n % 10
        n = n // 10
        if a % 2 == 0:
            c = c + b * (a // 2)
        else:
            ile += 1
            c = c + bx
        b = b * 10
    return c
ile = 0
print(F(333333666666999999), ile)

