with open('plansze.txt') as f:
    wiersze = [line.strip() for line in f]

ruchy = []
plansze = []
plansza = []
x = 0
for i in range(len(wiersze)):
    if i == x:
        if plansza != []:
            plansze.append(plansza[:])
            plansza.clear()
        ruchy.append(wiersze[i])
        x += 51
    plansza.append(wiersze[i])

def z1():
    ile = 0
    for i in range(len(plansze)):
        plansza = plansze[i]
        znaki = {}
        for wiersz in plansza:
            for znak in wiersz:
                if znak not in znaki:
                    znaki[znak] = 1
                else:
                    znaki[znak] += 1
        znakiSet = set(znaki)
        max = 0
        maxLitera = ""
        for znak in znakiSet:
            if znaki[znak] == max and znak == "R":
                maxLitera = "R"
            if znaki[znak] > max:
                max = znaki[znak]
                maxLitera = znak
        if maxLitera == 'R':
            if ile == 0:
                print(f"Pierwsza plansza: {i+1}")
            ile += 1
    print("Suma Plansz:", ile)

def z2():
    s = 0
    n = 0
    w = 0
    e = 0
    for i in range(len(ruchy)):
        kierunki = {}
        for znak in ruchy[i]:
            if znak not in kierunki:
                kierunki[znak] = 1
            else:
                kierunki[znak] += 1
        x = set(kierunki)
        poprawne = True
        max = 0
        maxKierunek = ''
        for znak in x:
            if kierunki[znak] == max and  kierunki[znak] != 0:
                poprawne = False
            if max < kierunki[znak]:
                max = kierunki[znak]
                maxKierunek = znak
                poprawne = True
        if poprawne:
            if maxKierunek == "S":
                s += 1
            if maxKierunek == "E":
                e += 1
            if maxKierunek == "W":
                w += 1
            if maxKierunek == "N":
                n += 1
    print(n,s,w,e)

def z3():
    ile = 0
    for ruch in ruchy:
        pozycja = 1
        pozycjaPionowo = 1
        for znak in ruch:
            if znak == "W":
                if pozycja == 1:
                    ile += 1
                else:
                    pozycja -= 1
            if znak == "E":
                if pozycja == 50:
                    ile += 1
                else:
                    pozycja += 1
            if znak == "N":
                if pozycjaPionowo == 1:
                    ile += 1
                else:
                    pozycjaPionowo -= 1
            if znak == "S":
                if pozycjaPionowo == 50:
                    ile += 1
                else:
                    pozycjaPionowo += 1
    print(ile)

print("Zadanie 1")
z1()
print("Zadanie 2")
z2()
print("Zadanie 3")
z3()