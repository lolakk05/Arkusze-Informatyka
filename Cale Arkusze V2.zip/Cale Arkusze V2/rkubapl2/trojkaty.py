import math

with open('trojkaty.txt') as f:
    trojkaty = [line.strip().split() for line in f]

for j in range(len(trojkaty)):
    for i in range(len(trojkaty[j])):
        trojkaty[j][i] = int(trojkaty[j][i])

def z1():
    poleMax = 0
    poleMin = 10000000000
    max = []
    min = []
    for trojkat in trojkaty:
        trojkat = sorted(trojkat)
        if (trojkat[0] * trojkat[0]) + (trojkat[1] * trojkat[1]) == (trojkat[2] * trojkat[2]):
            print(trojkat[0], trojkat[1], trojkat[2])
            pole = trojkat[0] * trojkat[1]
            if pole > poleMax:
                max = trojkat
                poleMax = pole
            if pole < poleMin:
                min = trojkat
                poleMin = pole
    print(max, min)

def z2():
    for trojkat in trojkaty:
        suma = sum(trojkat)
        dzielnik = 1
        sumaDzielnik = 0
        while dzielnik < suma:
            if suma % dzielnik == 0:
                sumaDzielnik += dzielnik
            dzielnik += 1
        if sumaDzielnik == suma:
            print(trojkat[0], trojkat[1], trojkat[2])

def z3():
    dl = 0
    max = 0
    pMax = []
    oMax = []
    pierwszy = []
    for i in range(len(trojkaty)-1):
        s1 = trojkaty[i][0] / trojkaty[i+1][0]
        s2 = trojkaty[i][1] / trojkaty[i+1][1]
        s3 = trojkaty[i][2] / trojkaty[i+1][2]
        if s1 == s2 == s3 and trojkaty[i][0] < trojkaty[i+1][0]:
            dl += 1
        else:
            if max < dl:
                max = dl
                pMax = pierwszy
                oMax = trojkaty[i]
            dl = 1
            pierwszy = trojkaty[i+1]
    if max < dl:
        max = dl
        pMax = pierwszy
        oMax = trojkaty[i]
    dl = 1
    pierwszy = trojkaty[i + 1]
    print(max, pMax, oMax)
print("Zadanie 1:")
z1()
print("Zadanie 2:")
z2()
print("Zadanie 3:")
z3()