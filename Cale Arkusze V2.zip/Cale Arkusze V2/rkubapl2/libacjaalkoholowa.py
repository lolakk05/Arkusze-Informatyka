# Zadanie 1
# 6 6
# 10 1
# 10 2
# Zadanie 2
# 9, 10, 11
# Zadanie 3
n = 5
x = 234
print(len(bin(x).lstrip('0b')))
dl = 0