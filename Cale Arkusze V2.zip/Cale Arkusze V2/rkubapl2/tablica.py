# Zadanie 1
# [6, 3, 2, 9, 5]
# [29, 10, 3, 0, -9]
# [33, 66, 99, 132, 165]
# Zadanie 2
# 93, 95
# 348, 350
# 264, 266
def f(t, n, i):
    if i >= n:
        return 0
    k = 0
    for y in range(0, n):
        if y != i:
            k = k + t[y]
    if t[i] < k // n:
        t[i] = t[i] * 3
    else:
        t[i] = t[i] // 3
    f(t, n, i+1)
g = [88, 33, 36, 39]

for x in range(0, 10000):
    t = [x, 11, 12, 13]
    f(t, 4, 0)
    if t == g:
        print(x, t)