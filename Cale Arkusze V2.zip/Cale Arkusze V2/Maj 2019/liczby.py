import math

with open('liczby.txt') as f:
    liczby = [line.strip() for line in f]

def nwd(a, b):
    if b != 0:
        return nwd(b, a%b)
    return a

def z1():
    ile = 0
    for liczba in liczby:
        if int(liczba) == 1 or int(liczba) == 3:
            ile += 1
        else:
            potega = 3
            while potega <= int(liczba):
                if potega == int(liczba):
                    ile += 1
                    break
                else:
                    potega *= 3
    print(ile)

def z2():
    for liczba in liczby:
        suma = 0
        for cyfra in liczba:
            silnia = 1
            for i in range(1, int(cyfra)+1):
                silnia *= i
            suma += silnia
        if int(liczba) == suma:
            print(liczba)

def z3():
    pierwszyMax = 0
    max = 0
    maxDzielnik = 0
    for i in range(len(liczby)-1):
        dlugosc = 1
        poczatek = 0
        j = i
        enwude = int(liczby[j])
        while math.gcd(enwude, int(liczby[j+1])) != 1:
            dlugosc += 1
            enwude = math.gcd(enwude, int(liczby[j+1]))
            if poczatek == 0:
                poczatek = liczby[j]
            j += 1
        if dlugosc > max:
            max = dlugosc
            pierwszyMax = poczatek
            maxDzielnik = enwude
    print(max, pierwszyMax, maxDzielnik)


print("Zadanie 1")
z1()
print("Zadanie 2")
z2()
print("Zadanie 3")
z3()

print(nwd(5, 25))