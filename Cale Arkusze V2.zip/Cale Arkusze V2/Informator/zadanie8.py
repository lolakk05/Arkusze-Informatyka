with open('dane8.txt') as f:
    liczby = [int(line.strip()) for line in f]

def z1():
    ileParzystych = 0
    ileNieparzystych = 0
    for i in range(1, len(liczby)):
        wartosc = abs(liczby[i] - liczby[i-1])
        if wartosc % 2 == 0:
            ileParzystych += 1
        else:
            ileNieparzystych += 1
    print(ileParzystych, ileNieparzystych)

def z2():
    ile = 0
    for i in range(len(liczby)):
        for j in range(i, len(liczby)):
            if liczby[j] < liczby[i] and i < j:
                ile += 1
    print(ile)

def z3():
    dl = 1
    maks = 0
    for i in range(1, len(liczby)):
        if liczby[i] > liczby[i-1]:
            dl += 1
        else:
            if dl > maks:
                maks = dl
            dl = 1
    print(maks)


z1()
z2()
z3()