# Zadanie 4.1
# 0
#
with open('dane4.txt') as f:
    liczby = [int(line) for line in f]

maks = 0
maksi = 0
for i in range(len(liczby)):
    ile = 0
    for j in range(0, i):
        if liczby[j] < liczby[i]:
            ile += 1
    if ile >= maks:
        maks = ile
        maksi = i
print(maksi+1)