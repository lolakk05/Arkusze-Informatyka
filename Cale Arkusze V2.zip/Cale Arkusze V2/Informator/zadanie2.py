# Zadanie 2.1
# Tak
# Nie
# Tak
# Zadanie 2.2
# 1
# 2
# 3
# 4
def z2_3():
    with open('dane2_3.txt') as f:
        nawiasy = [line for line in f]
    for nawias in nawiasy:
        maxGlebokosc = 0
        gleboskosc = 0
        for znak in nawias:
            if znak == "[":
                gleboskosc += 1
            if znak == ']':
                gleboskosc -= 1
            if gleboskosc > maxGlebokosc:
                maxGlebokosc = gleboskosc
        print(maxGlebokosc)

def z2_4():
    with open('dane2_4.txt') as f:
        nawiasy = [line for line in f]
    for nawias in nawiasy:
        ileLewy = 0
        ilePrawy = 0
        for znak in nawias:
            if znak == '[':
                ileLewy += 1
            if znak == ']':
                ilePrawy += 1
        if ileLewy == ilePrawy:
            print('git')
        else:
            print("nie")

z2_3()
z2_4()