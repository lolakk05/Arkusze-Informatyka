with open('dane6.txt') as f:
    liczby = [line.strip() for line in f]

def z1():
    for p in range(2, 11):
        ile = 0
        for liczba in liczby:
            pMinimalna = False
            for znak in liczba:
                if int(znak) == p - 1:
                    pMinimalna = True
                if int(znak) > p - 1:
                    pMinimalna = False
                    break
            if pMinimalna:
                ile += 1
        print(p, ": ", ile)

def z2():
    for p in range(2, 11):
        maks = 0
        maksLiczba = ''
        for liczba in liczby:
            pMinimalna = False
            for znak in liczba:
                if int(znak) == p - 1:
                    pMinimalna = True
                if int(znak) > p - 1:
                    pMinimalna = False
                    break
            if pMinimalna:
                suma = 0
                for znak in liczba:
                    suma += int(znak)
                if suma > maks:
                    maks = suma
                    maksLiczba = liczba
        print(p, ": ", maksLiczba)

def z3():
    ile = 0
    for liczba in liczby:
        n = len(liczba)
        poprawna = True
        if n % 2 == 0:
            for i in range(0, n//2):
                if liczba[n - i - 1] != liczba[i]:
                    continue
                else:
                    poprawna = False
                    break
        if poprawna:
            ile += 1
            print(liczba)
    print(ile)
z1()
z2()
z3()