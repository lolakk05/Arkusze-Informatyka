#Zadanie 7
#ALGORYTM

with open('szyfrogram.txt') as f:
    szyfry = [line.strip() for line in f]

def z1():
    ileRazy = {}
    for szyfr in szyfry:
        for znak in szyfr:
            if znak not in ileRazy:
                ileRazy[znak] = 1
            else:
                ileRazy[znak] += 1
    return ileRazy

def z3():
    pasujace = []
    for znak in ileRazy:
        for znak1 in czestosc:
            liczba1 = int(ileRazy[znak])
            liczba2 = int(czestosc[znak1])
            print(liczba1, liczba2)
            if liczba1 == liczba2:
                para = znak + znak1
                pasujace.append(para)
                print('git')
    for szyfr in szyfry:
        pomoc = ''
        for i in range(len(szyfr)):
            litera = szyfr[i]
            for para in pasujace:
                if para[0] == litera:
                    litera = para[1]
                    break
            pomoc += litera
        print(pomoc)
z1()
ileRazy = z1()
print(ileRazy)
with open('czestosc.txt') as f:
    wiersze = [line.strip().split() for line in f]
czestosc = {}
for i in range(len(wiersze)):
    czestosc[wiersze[i][0]] = wiersze[i][1]
z3()