def W(j):
    if j > 0:
        if A[j] < A[j-1]:
            v = A[j]
            A[j] = A[j-1]
            A[j-1] = v
            return W(j-1)


def W1(j):
    while j > 0:
        if A[j] < A[j-1]:
            v = A[j]
            A[j] = A[j-1]
            A[j-1] = v
        j -= 1

A = [2,4,6,8,10,9,7,5,3,1]
W(7)
print(A)