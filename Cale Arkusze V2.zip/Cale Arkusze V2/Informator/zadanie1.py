def z1_3():
    with open('dane1_3.txt') as f:
        liczby = [int(line) for line in f]


    maks = 0
    suma = 0
    for i in range(len(liczby)):
        suma = 0
        for j in range(i, len(liczby)):
            suma += liczby[j]
            if suma > maks:
                maks = suma
    print(maks)

def z1_4():
    with open('dane1_4.txt') as f:
        liczby = [int(line) for line in f]

    maks = 0
    suma = 0
    pierwszy = 0
    ostatni = 0
    for i in range(len(liczby)):
        suma = 0
        print(i)
        for j in range(i, len(liczby)):
            suma += liczby[j]
            if maks < suma:
                maks = suma
                pierwszy = i + 1
                ostatni = j + 1
    print(pierwszy, ostatni)


z1_4()