from collections import Counter

with open('dane3.txt') as f:
    przedzialy = [line.strip().split() for line in f]

for i in range(len(przedzialy)):
    przedzialy[i][0] = int(przedzialy[i][0])
    przedzialy[i][1] = int(przedzialy[i][1])

przedzialy.sort()

def z1():
    dl = [4046, 4046]
    for przedzial in przedzialy:
        odleglosc = abs(przedzial[1] - przedzial[0]) + 1
        if odleglosc < dl[1]:
            dl[1] = odleglosc
        dl.sort()
    print(dl)

def z2():
    dl = {}
    for przedzial in przedzialy:
        odleglosc = abs(przedzial[1] - przedzial[0]) + 1
        if odleglosc not in dl:
            dl[odleglosc] = 1
        else:
            dl[odleglosc] += 1
    print(Counter(dl).most_common()[0])

def z3():
    maks = 0
    for i in range(1, len(przedzialy)):
        dlugosc = 1
        for j in range(i, len(przedzialy)):
            if przedzialy[j][0] > przedzialy[j-1][0] and przedzialy[j][0] < przedzialy[j-1][1]:
                dlugosc += 1
            else:
                break
        if dlugosc > maks:
            maks = dlugosc
    print(maks)

z1()
z2()
print(przedzialy)
z3()