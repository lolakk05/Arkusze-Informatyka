with open('przyklad.txt') as f:
    wega = [line.strip() for line in f]

def z1():
    haslo = ""
    for i in range(len(wega)):
        if (i+1) % 40 == 0:
            haslo += wega[i][9]
    print(haslo)

def z2():
    max = 0
    haslo = ""
    for slowo in wega:
        litery = []
        for znak in slowo:
            if znak not in litery:
                litery.append(znak)
        if len(litery) > max:
            max = len(litery)
            haslo = slowo
    print(haslo, max)

def z3():
    for slowo in wega:
        poprawne = True
        for i in range(len(slowo)):
            for j in range(len(slowo)):
                if (ord(slowo[j]) - ord(slowo[i])) > 10:
                    poprawne = False
        if poprawne:
            print(slowo)
print("Zadanie 1")
z1()
print("Zadanie 2")
z2()
print("Zadanie 3")
z3()