with open("dane.txt") as f:
    liczby = [line.strip() for line in f]

def z1():
    ile = 0
    for liczba in liczby:
        if liczba[0] == liczba[-1]:
           ile += 1
    print(ile)

def z2():
    ile = 0
    for liczba in liczby:
        liczba = str(int(liczba, 8))
        if liczba[0] == liczba[-1]:
            ile += 1
    print(ile)

def z3():
    ile = 0
    min = 10000000
    max = 0
    for liczba in liczby:
        git = True
        for i in range(len(liczba)-1):
            if liczba[i] > liczba[i+1]:
                git = False
        if git:
            ile += 1
            if int(liczba) > max:
                max = int(liczba)
            if int(liczba) < min:
                min = int(liczba)
    print(ile, min, max)
print("Zadanie 1:")
z1()
print("Zadanie 2:")
z2()
print("Zadanie 3:")
z3()