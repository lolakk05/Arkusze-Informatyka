with open("prostokaty.txt") as f:
    prostokaty = [line.strip().split() for line in f]

def z1():
    poleMax = 0
    poleMin = 40000
    for prostokat in prostokaty:
        wysokosc = int(prostokat[0])
        szerokosc = int(prostokat[1])
        pole = wysokosc * szerokosc
        if pole > poleMax:
            poleMax = pole
        if pole < poleMin:
            poleMin = pole
    print(poleMax, poleMin)

def z2():
    dl = 1
    max = 0
    ostatni = 0
    for i in range(1, len(prostokaty)):
        if int(prostokaty[i-1][0]) >= int(prostokaty[i][0]) and int(prostokaty[i-1][1]) >= int(prostokaty[i][1]):
            dl += 1
        else:
            if max < dl:
                max = dl
                ostatni = prostokaty[i-1]
            dl = 1
    print(max, ostatni)

def z3():
    wysokosci = {}
    maxDwa = 0
    maxTrzy = 0
    maxPiec = 0
    for prostokat in prostokaty:
        if int(prostokat[0]) not in wysokosci:
            wysokosci[int(prostokat[0])] = [int(prostokat[1])]
        else:
            wysokosci[int(prostokat[0])].append(int(prostokat[1]))
    for wysokosc in wysokosci:
        szerokosci = wysokosci[wysokosc]
        szerokosci.sort()
        szerokosci.reverse()
        dl = 0
        suma = 0
        for szerokosc in szerokosci:
            dl += 1
            suma += szerokosc
            if dl == 2 and suma > maxDwa:
                maxDwa = suma
            if dl == 3 and suma > maxTrzy:
                maxTrzy = suma
            if dl == 5 and suma > maxPiec:
                maxPiec = suma
    print(maxDwa, maxTrzy, maxPiec)

print("Zadanie 1")
z1()
print("Zadanie 2")
z2()
print("Zadanie 3")
z3()