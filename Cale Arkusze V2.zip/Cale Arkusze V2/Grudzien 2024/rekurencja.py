# Zadanie 2.1
# 2 6
# 7 5
# Zadanie 2.2
# 96
# 97

def F(x, p):
    global ile
    if x == 0:
        return 0
    else:
        c = x % p
        ile += 1
        if c % 2 == 1:
            return F(x//p, p) + c
        else:
            return F(x//p, p) - c

ile = 1
for x in range(0, 100):
    if F(x, 4) == 0:
        print(x)
