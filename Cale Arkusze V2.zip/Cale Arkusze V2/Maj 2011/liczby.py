with open('liczby.txt') as f:
    liczby = [line.strip() for line in f]

def z1():
    ile = 0
    for liczba in liczby:
        liczba = int(liczba, 2)
        if liczba % 2 == 0:
            ile += 1
    print(ile)

def z2():
    maks = 0
    maksBin = ''
    for liczba in liczby:
        liczba1 = int(liczba, 2)
        if liczba1 > maks:
            maks = liczba1
            maksBin = liczba
    print(maks, maksBin)

def z3():
    ile = 0
    for liczba in liczby:
        if len(liczba) == 8:
            ile += 1
    print(ile)
z1()
z2()
z3()