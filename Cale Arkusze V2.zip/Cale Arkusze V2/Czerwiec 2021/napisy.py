with open('napisy.txt') as f:
    napisy = [line.strip() for line in f]

def z1():
    ile = 0
    for napis in napisy:
        for znak in napis:
            if ord(znak) > 47 and ord(znak) < 58:
                ile += 1
    print(ile)

def z2():
    wiersz = 1
    pozycja = 0
    haslo = ''
    for napis in napisy:
        if wiersz % 20 == 0:
            haslo += napis[pozycja]
            pozycja += 1
        wiersz += 1
    print(haslo)

def z3():
    haslo = ''
    for napis in napisy:
        test1 = napis + napis[0]
        test2 = napis[-1] + napis
        if test1 == test1[::-1]:
            haslo += test1[len(test1) // 2]
        if test2 == test2[::-1]:
            haslo += test2[len(test2) // 2]
    print(haslo)

def z4():
    haslo = ''
    ileX = 0
    for napis in napisy:
        para = ''
        for znak in napis:
            if ord(znak) > 47 and ord(znak) < 58:
                para += znak
            if len(para) == 2:
                if int(para) >= 65 or int(para) <= 95:
                    haslo += chr(int(para))
                    if chr(int(para)) == 'X':
                        ileX += 1
                    else:
                        ileX = 0
                para = ""
            if ileX == 3:
                return haslo

z1()
z2()
z3()
print(z4())