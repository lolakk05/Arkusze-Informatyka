dl = 0
n = 23
liczba = n
while n > 0:
    kwadrat = liczba * liczba
    if kwadrat <= n:
        n -= kwadrat
        dl += 1
    else:
        liczba -= 1

print(dl)