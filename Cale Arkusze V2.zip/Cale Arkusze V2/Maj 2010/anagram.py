with open('anagram.txt') as f:
    wiersze = [line.strip().split() for line in f]

def z1():
    for slowa in wiersze:
        d = len(slowa[0])
        poprawne = True
        for slowo in slowa:
            if len(slowo) != d:
                poprawne = False
        if poprawne:
            print(slowa)

def z2():
    for slowa in wiersze:
        pierwszy = {}
        poprawne = True
        for i in range(len(slowa[0])):
            if slowa[0][i] not in pierwszy:
                pierwszy[slowa[0][i]] = 1
            else:
                pierwszy[slowa[0][i]] += 1
        for slowo in slowa:
            obecny = {}
            for i in range(len(slowo)):
                if slowo[i] not in obecny:
                    obecny[slowo[i]] = 1
                else:
                    obecny[slowo[i]] += 1
            if obecny != pierwszy:
                poprawne = False
        if poprawne:
            print(slowa)

z1()
print("Zadanie 2:")
z2()