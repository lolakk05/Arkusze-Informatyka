with open('pi.txt') as f:
    liczby = [line.strip() for line in f]

def z1():
    ile = 0
    for i in range(1, len(liczby)):
        para = liczby[i-1] + liczby[i]
        para = int(para)
        if para > 90:
            ile += 1
    print(ile)

def z2():
    wystapienia = {'00': 0}
    for i in range(1, len(liczby)):
        para = liczby[i-1] + liczby[i]
        if para not in wystapienia:
            wystapienia[para] = 1
        else:
            wystapienia[para] += 1
    maks = 0
    min = 10000
    maksPara = ''
    minPara = ''
    for para in wystapienia:
        if wystapienia[para] > maks:
            maks = wystapienia[para]
            maksPara = para
        if wystapienia[para] < min:
            min = wystapienia[para]
            minPara = para
    print(minPara, min, maksPara, maks)

def czyPoprawny(ciag):
    for j in range(1, len(ciag)):
        if ciag[j] > ciag[j - 1]:
            continue
        else:
            for k in range(j + 1, len(ciag)):
                if ciag[k] < ciag[k - 1]:
                    continue
                else:
                    return False
    return True

def z3():
    ile = 0
    for i in range(len(liczby)):
        ciag = liczby[i:i+6]
        for c in range(len(ciag)):
            ciag[c] = int(ciag[c])
        if czyPoprawny(ciag) and len(ciag) == 6:
            print(ciag)
            ile += 1
    print(ile)

def z4():
    maksCiag = ''
    wiersz = 0
    for i in range(len(liczby)):
        ciag = liczby[i]
        print(i)
        for j in range(i+1, len(liczby)):
            ciag += liczby[j]
            if czyPoprawny(ciag):
                if len(maksCiag) < len(ciag):
                    maksCiag = ciag
                    wiersz = i + 1
    print(wiersz)
    print(maksCiag)

# z1()
# z2()
z3()
# z4()