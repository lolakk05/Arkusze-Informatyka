with open('bin.txt') as f:
    liczby = [line.strip() for line in f]

def z1(n):
    bloki = 1
    ostatnia = 5
    while n > 0:
        cyfra  = n % 2
        if ostatnia != 5:
            if ostatnia != cyfra:
                bloki += 1
        ostatnia = cyfra
        n //= 2
    print(bloki)


def z2():
    ile = 0
    for liczba in liczby:
        bloki = 1
        for i in range(1, len(liczba)):
            if liczba[i] != liczba[i-1]:
                bloki += 1
        if bloki <= 2:
            ile += 1
    print(ile)

def z3():
    maks = 0
    maksBin = ''
    for liczba in liczby:
        if maks < int(liczba, 2):
            maks = int(liczba, 2)
            maksBin = liczba
    print(maksBin)

def z5():
    print("Zadanie 2.5")
    for liczba in liczby:
        p = int(int(liczba, 2) / 2)
        p = bin(p)[2:]
        if len(p) != len(liczba):
            p = p[::-1]
            while len(p) != len(liczba):
                p += '0'
            p = p[::-1]
        xor = ''
        for i in range(len(liczba)):
            if liczba[i] == p[i]:
                xor += '0'
            else:
                xor += '1'
        print(xor)
#z1(245)
z2()
print("Zadanie 2.3")
z3()
print("Zadanie 2.4")
print(int('1111011', 2))
z5()