import math

def sito(pierwsze, n):
    # Oznacz 0 i 1 jako niepierwsze
    pierwsze[0] = 1
    pierwsze[1] = 1
    # Sito Eratostenesa
    for i in range(2, int(math.sqrt(n)) + 1):
        if pierwsze[i] == 0:  # Jeśli i jest pierwsze
            j = i * i  # Zaczynamy od i*i, bo mniejsze wielokrotności już oznaczone
            while j <= n:
                pierwsze[j] = 1  # Oznacz jako niepierwsze
                j += i

# Inicjalizacja tablicy
n = 1000000
pierwsze = [0] * (n + 1)  # Tablica od 0 do n
sito(pierwsze, n)

# Wypisz liczby pierwsze
for i in range(n + 1):
    if pierwsze[i] == 0:
        print(i)