def z1():
    with open('dane_6_1.txt') as f:
        slowa = [line.strip() for line in f]
    for slowo in slowa:
        noweSlowo = ""
        for litera in slowo:
            noweSlowo += chr((ord(litera) - ord("A") + 107) % 26 + ord("A"))
        print(noweSlowo)

def z2():
    with open('dane_6_2.txt') as f:
        slowa = [line.split() for line in f]
    for slowo in slowa:
        noweSlowo = ""
        klucz = slowo[1]
        szyfr = slowo[0]
        for znak in szyfr:
            noweSlowo += chr((ord(znak) - ord("A") - int(klucz)) % 26 + ord("A"))
        print(noweSlowo)

def z3():
    with open("dane_6_3.txt") as f:
        slowa = [line.split() for line in f]
    for slowo in slowa:
        slowo1 = slowo[0]
        slowo2 = slowo[1]
        roznica = (ord(slowo2[0]) - ord(slowo1[0])) % 26
        git = True
        for i in range(1, len(slowo1)):
            przesuniecie = (ord(slowo2[i]) - ord(slowo1[i])) % 26
            if przesuniecie != roznica:
                git = False
                break
        if not git:
            print(slowo1)





print("Zadanie 1")
#z1()
print("Zadanie 2")
#z2()
print("Zadanie 3")
z3()