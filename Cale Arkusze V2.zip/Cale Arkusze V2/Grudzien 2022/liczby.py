import math

with open('liczby_przyklad.txt') as f:
    liczby = [int(line.strip()) for line in f]

def czy_pierwsza(n):
    if n < 2:
        return False
    for i in range(2, int(math.sqrt(n))+1):
        if n % i == 0:
            return False
    return True

def sito():
    sito = [True] * 1000000
    sito[0] = False
    sito[1] = False
    for i in range(2, 1000000):
        if sito[i] == True:
            j = i * i
            while j < 1000000:
                sito[j] = False
                j = j + i
    pierwsze = []
    for i in range(1000000):
        if sito[i] == True:
            pierwsze.append(i)
    return pierwsze

def z1():
    ile = 0
    for liczba in liczby:
        if czy_pierwsza(liczba-1):
            ile += 1
    print(ile)

def z2():
    pierwsze = sito()
    maks = [0, 0]
    min = [10000000, 10000000]
    for liczba in liczby:
        for i in range(len(pierwsze)):
            for j in range(i, len(pierwsze)):
                if

z1()
z2()