with open('mecz_przyklad.txt') as f:
    mecz = f.readline().strip()

def z1():
    ile = 0
    for i in range(1,len(mecz)):
        if mecz[i] != mecz[i-1]:
            ile += 1
    print(ile)

def z2():
    A = 0
    B = 0
    for rozgrywka in mecz:
        if rozgrywka == "A":
            A += 1
        else:
            B += 1
        if A >= 1000 and A - B >= 3:
            print("A", f"{A}:{B}")
            break
        if B >= 1000 and B - A >= 3:
            print("B", f"{A}:{B}")
            break

def z3():
    ostatni = ''
    ile = 0
    passa = 0
    max = 0
    druzyna = ''
    for rozgrywka in mecz:
        if ostatni == rozgrywka:
            passa += 1
        else:
            if passa >= 10:
                ile += 1
                if passa > max:
                    max = passa
                    druzyna = ostatni
            passa = 1
        ostatni = rozgrywka
    print(ile, max, druzyna)

z1()
z2()
z3()